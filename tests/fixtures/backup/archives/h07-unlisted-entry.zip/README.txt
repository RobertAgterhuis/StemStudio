StemStudio library backup (format stemstudio-backup 1.0.0).

This is a test fixture of the StemStudio repository (tests/fixtures/backup).
To restore an archive, copy it into the backups folder and open Library care -> Backups.
It contains voice samples and is not encrypted; keep it on a protected drive.
