Holiday photos, not a backup.
